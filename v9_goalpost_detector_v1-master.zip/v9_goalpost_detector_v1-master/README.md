# v9_goalpost_detector

C++ implementation of paper titled, as included
