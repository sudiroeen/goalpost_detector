/*
   Copyright by:
      Sudiro
         [at] SudiroEEN@gmail.com
 */

#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include<stdio.h>
#include <math.h>
#include "regression.cpp"
using namespace cv;
using namespace std;
int main()
{
      int Lh=23,// nilai sesuai yang diperoleh saat treshold warna kuning
             Ls=160,
             Lv = 175,
             Hh = 126,
             Hs = 250,
             Hv = 255;

    float VEKTOR_1[2],VEKTOR_2[2];
    Mat src = imread("goal_1.png");
    Mat src1 = src.clone();

    if(src1.empty())
    {
       cout << "can not open " << endl;
        return -1;
    }

    Mat dst;
    cvtColor(src1,dst,CV_BGR2HSV);
    inRange(src1,Scalar(Lh,Ls,Lv), Scalar(Hh,Hs,Hv),dst);
    imshow("dst",dst);

   erode(dst,dst,getStructuringElement(MORPH_RECT,Size(3,3)),Point(-1,-1),3);
   dilate(dst,dst,getStructuringElement(MORPH_RECT,Size(3,3)),Point(-1,-1),4);

   /* di bawah ini menggunakan morphologyEx MORPH_GRADIENT untuk meminimalisir
    * titik kuning yang terbaca yang awalnya penuh satu batang, sekarang tinggal
    * pinggirnya */
   morphologyEx(dst,dst,MORPH_GRADIENT,getStructuringElement(MORPH_RECT,Size(3,3)));
   imshow("edge",dst);

   Mat htl;
   /* dilakukan erode pada vertikalnya, karena yang akan diproses garis horizontal*/
   erode(dst,htl,getStructuringElement(MORPH_RECT,Size(dst.cols/50,1)),Point(-1,-1),2);
   imshow("horizontal",htl);

   /* regression(Mat Mentah,Mat& source,int pilihan,float arr[2]);
    *
    * Mat Mentah -> untuk memasukkan gambar yang akan diesrimasi garisnya
    * Mat& source -> gambar asli sebelum diapa - apakan untuk mengetahui hasil nya
    * int pilihan -> 0 untuk estimasi garis horizontal(mistar gawang), 1 untuk estimasi
    *                  garis vertikal (tiang gawang)
    * arr[2] -> untuk menyimpan data garis hasil estimasi dalam bentuk vektor
    *           untuk operasi dot product
    */
   Point2f goal_1,goal_2;
   regression(htl,src1,0,VEKTOR_1,goal_1);
   imshow("hasil",src1);

Mat vtl;
/* dilakukan erode pada horizontalnya karena yang diproses yang vertikal*/
erode(dst,vtl,getStructuringElement(MORPH_RECT,Size(1,dst.rows/50)),Point(-1,-1),2);
/* ditranspose karena pencarian titik berwarna kuning dilakukan penyusuran horizontal*/
transpose(vtl,vtl);
imshow("vertikaltranspose",vtl);

regression(vtl,src1,1,VEKTOR_2,goal_2);

float angle;//menyimpan nilai sudut antara dua garis estimasi (fitted line) untuk pengecekan
float dot,panjangKali;

dot =VEKTOR_1[0]*VEKTOR_2[0]+VEKTOR_1[1]*VEKTOR_2[1];//operasi dot product

//panjang VEKTOR_1 dikali panjang VEKTOR_2
panjangKali = sqrt(pow(VEKTOR_1[0],2)+pow(VEKTOR_1[1],2))
              * sqrt(pow(VEKTOR_2[0],2)+ pow(VEKTOR_2[1],2));

//nilai sudut dalam satuan derajat
angle = acos(dot/panjangKali)*180/CV_PI;
cout<<endl<<endl<<endl<<"angle: "<<angle<<endl;
cout<<endl<<endl<<"Tujuan goal: "<<0.5 *(goal_1+goal_2)<<endl;
/* mengecek nilai sudut untuk memastikan gawang
 * (mistar terhadap tiang 90 derajat) disertai toleransi*/
if(angle<95 && angle>85)
    circle(src1,0.5 *(goal_1+goal_2),9,Scalar(255,0,0),-1);

imshow("hasil_akhir",src1);
imwrite("segmented1.jpg", src1);
waitKey(0);
}
