# Yellow-Goal-Detection

# Idea:
- using perpendicular part between goal post and crossbar as identity of goal
