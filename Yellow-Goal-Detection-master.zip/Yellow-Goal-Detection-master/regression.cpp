#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace cv;
using namespace std;

int regression(Mat mentah, Mat& source,int pilihan,float arr[2],Point2f& tujuan)
 {
   vector<Vec2i>TITIK;
      int cacah;
      int flag=0,par=0;

      //pencarian titik berwarna kuning secara horizontal kiri ke kanan
    for(int i=0;i<mentah.rows;i++)
     {
       uchar *mentahPtr = mentah.ptr(i);
       cacah=0;
      for(int j=0;j<mentah.cols;j++)
       {
        if(mentahPtr[j]&&(!flag))
          {
              TITIK.push_back(Point2i(j,i));
              flag=1;
              cacah++;
              par++;
            }
          else if(mentahPtr[j]&flag)
          {
              TITIK.push_back(Point2i(j,i));
              cacah++;
              par++;
          }
      }
      if((!cacah)&flag)
          break;
    }

    int fit[par][2];//Matrix dengan baris sebanyak sample yang diperoleh, dan dua kolom
      for(int a = 0;a<par;a++)
       {
          //kolom pertama berisikoordinat sample
          fit[a][0]=TITIK[a][0];

          //kolom ke dua hanya berisi angka 1,
          //lebih jelasnya di referensi yang saya kirim
          fit[a][1]=1;
       }//diperoleh sekitar 447 titik

    int tps[2][par];//mentraspose matrix tersebut
       for(int d=0;d<2;d++)
         {
           for(int c=0;c<par;c++)
              {
                  tps[d][c] = fit[c][d];
              }
         }

    unsigned int AtA[2][2];// menyimpan nilai matrix (A_transpose * A)
             for(int e=0;e<2;e++)
             {
                 for(int g=0;g<2;g++)
                 {
                     for(int f=0;f<par;f++)
                        {
                            if(f==0)
                                AtA[e][g]=0;
                                AtA[e][g] += tps[e][f]*fit[f][g];
                         }
                     cout<<AtA[e][g]<<"\t";
                    }
                 cout<<endl;
               }
    int Atb[2];// A_transpose * b
                       for(int h=0;h<2;h++)
                           for(int i=0;i<par;i++)
                                {
                               if(i==0)
                                   Atb[h]=0;
                               Atb[h]+=tps[h][i]*TITIK[i][1];
                                  }
    double iNV[2][2];
    double det= AtA[0][0]*AtA[1][1]-AtA[1][0]*AtA[0][1];
        if(det==0)
            return -1;
    printf("DET     %.lf\n",det);
    double Idet=1/det;
    printf("Idet    %.17lf\n\n",Idet);
      iNV[0][0]=Idet*AtA[1][1];
      iNV[1][1]=Idet*AtA[0][0];
      iNV[1][0]=Idet*(-1)*AtA[1][0];
      iNV[0][1]=Idet*(-1)*AtA[0][1];
    double mc[2];
      for(int e=0;e<2;e++)
        for(int f=0;f<2;f++)
           {
           if(f==0)
              mc[e]=0;

            mc[e]+=iNV[e][f]*Atb[f];
          printf("\n%.17lf\t%d\n",iNV[e][f],Atb[f]);
          }
      printf("\n\n\n\n%.17lf\t%.17lf\n",mc[0],mc[1]);
   float sb_y[par];

         sb_y[0]=fit[0][0]*mc[0]+mc[1];
         sb_y[par-1]=fit[par-1][0]*mc[0]+mc[1];

    if(pilihan==0)
    {
        line(source,Point(fit[0][0],sb_y[0]),Point(fit[par-1][0],sb_y[par-1]),Scalar(0,0,255),3,LINE_AA);
           arr[0]= fit[par-1][0]-fit[0][0];
           arr[1]= sb_y[par-1]-sb_y[0];
           tujuan = 0.5 * (Point(fit[0][0],sb_y[0]) + Point(fit[par-1][0],sb_y[par-1]));

     }
    else{
        line(source,Point(sb_y[0],fit[0][0]),Point(sb_y[par-1],fit[par-1][0]),Scalar(0,255,0),3,LINE_AA);
           arr[0]= sb_y[par-1]-sb_y[0];
           arr[1]= fit[par-1][0]-fit[0][0];
           tujuan = 0.5 * (Point(sb_y[0],fit[0][0]) + Point(sb_y[par-1],fit[par-1][0]));
        }
    return 0;
}
